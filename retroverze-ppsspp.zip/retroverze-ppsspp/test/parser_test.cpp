#include <algorithm>
#include <cstring>
#include <cctype>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include "pugixml.hpp"
static const char *kLobbyGameName = "Monster Hunter Portable 3rd";
// Auto refresh (detik) saat pause menu terbuka dan tab Lobby Status aktif. 0 = hanya manual.
static const double kLobbyAutoRefreshSec = 20.0;
// Batas waktu request sebelum dianggap gagal (detik).
static const double kLobbyTimeoutSec = 15.0;
// Jeda minimum antar request (detik), supaya tombol Refresh tidak dispam.
static const double kLobbyMinIntervalSec = 2.0;
// Batas karakter nickname (sama seperti website).
static const size_t kLobbyMaxNickChars = 10;

// Potong string UTF-8 berdasarkan jumlah karakter (bukan byte) agar tidak merusak karakter multibyte.
static std::string TruncateUtf8(const std::string &s, size_t maxChars) {
	size_t chars = 0, i = 0;
	while (i < s.size()) {
		if ((static_cast<unsigned char>(s[i]) & 0xC0) != 0x80) {
			if (chars == maxChars)
				break;
			chars++;
		}
		i++;
	}
	return s.substr(0, i);
}

static std::string TrimCopy(const std::string &s) {
	size_t a = 0, b = s.size();
	while (a < b && isspace(static_cast<unsigned char>(s[a]))) a++;
	while (b > a && isspace(static_cast<unsigned char>(s[b - 1]))) b--;
	return s.substr(a, b - a);
}

// Nama group dari server -> judul tampilan. Format server saat ini: "GH 01 A".
// Format lama (MHP3Q0 / MHP3Q0A) tetap didukung: angka dimulai dari 0, jadi MHP3Q0 -> "GH 01".
static bool NormalizeGroupName(const std::string &name, std::string *title) {
	if (name.compare(0, 3, "GH ") == 0) {
		*title = TrimCopy(name);
		return true;
	}
	static const char *kLegacyPrefix = "MHP3Q";
	const size_t plen = strlen(kLegacyPrefix);
	if (name.compare(0, plen, kLegacyPrefix) == 0) {
		size_t i = plen;
		while (i < name.size() && isdigit(static_cast<unsigned char>(name[i]))) i++;
		if (i == plen)
			return false;
		const int num = atoi(name.substr(plen, i - plen).c_str());
		char head[32];
		snprintf(head, sizeof(head), "GH %02d", num + 1);
		*title = head;
		if (i < name.size())
			*title += " " + name.substr(i);
		return true;
	}
	return false;
}

// Parse status.xml -> baris "GH 01 A (2) - nama1, nama2". Hanya GH yang ada pemainnya.
// Alamat IP pemain di XML sengaja tidak dibaca. Return false jika XML tidak valid / bukan format yang dikenal.
static bool ParseLobbyXml(const std::string &xml, std::vector<std::string> *lines, int *players) {
	lines->clear();
	*players = 0;
	pugi::xml_document doc;
	if (!doc.load_buffer(xml.data(), xml.size()))
		return false;

	bool sawGame = false;
	auto handleGame = [&](pugi::xml_node game) {
		sawGame = true;
		if (std::string(game.attribute("name").as_string()) != kLobbyGameName)
			return;
		int total = 0;
		for (pugi::xml_node group : game.children("group")) {
			std::string title;
			if (!NormalizeGroupName(group.attribute("name").as_string(), &title))
				continue;
			std::string names;
			int count = 0;
			for (pugi::xml_node user : group.children("user")) {
				std::string n = TruncateUtf8(TrimCopy(user.child_value()), kLobbyMaxNickChars);
				if (n.empty())
					continue;
				if (count)
					names += ", ";
				names += n;
				count++;
			}
			if (count == 0)
				continue;
			total += count;
			lines->push_back(title + " (" + std::to_string(count) + ") - " + names);
		}
		*players = total;
	};

	for (pugi::xml_node top : doc.children()) {
		if (std::string(top.name()) == "game") {
			handleGame(top);
		} else {
			for (pugi::xml_node game : top.children("game"))
				handleGame(game);
		}
	}
	std::sort(lines->begin(), lines->end());
	return sawGame;
}


int main(int argc, char**argv){
  std::ifstream f(argv[1]); std::stringstream ss; ss<<f.rdbuf();
  std::vector<std::string> lines; int players=0;
  bool ok = ParseLobbyXml(ss.str(), &lines, &players);
  std::cout<<"ok="<<ok<<" players="<<players<<"\n";
  for (auto&l: lines) std::cout<<l<<"\n";
  std::vector<std::string> l2; int p2;
  std::cout<<"garbage ok="<<ParseLobbyXml("<html><body>oops</html", &l2,&p2)<<"\n";
  std::cout<<"html ok="<<ParseLobbyXml("<html><body>Maintenance</body></html>", &l2,&p2)<<"\n";
  std::cout<<"empty ok="<<ParseLobbyXml("", &l2,&p2)<<"\n";
}
