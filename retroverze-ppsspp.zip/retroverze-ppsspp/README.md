# PPSSPP RetroVerze Edition

PPSSPP 1.20.4 + tab **Lobby Status** (GH Monster Hunter Portable 3rd) di pause screen.

## Isi paket
- `overlay/UI/PauseScreen.cpp|.h` : fitur Lobby Status (native, tanpa WebView)
- `apply_retroverze.sh` : menerapkan overlay + package name baru `id.retroverze.ppsspp` + nama app "PPSSPP RetroVerze" + opsi build ARM64
- `.github/workflows/retroverze_apk.yml` : build APK bertanda tangan di GitHub Actions
- `test/` : contoh `status.xml` dan tes parser

## Cara pakai (cukup dari HP lewat web GitHub)
1. Buat repo GitHub baru (private), upload seluruh isi folder ini.
2. Settings -> Secrets and variables -> Actions -> buat: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` (retroverze), `KEY_PASSWORD`.
3. Tab Actions -> "Build PPSSPP RetroVerze Edition" -> Run workflow.
   Pastikan `upstream_ref` sama dengan versi source kamu (default `v1.20.4`).
4. Selesai (~30-60 menit) -> unduh artifact `PPSSPP-RetroVerze-arm64` -> pasang APK.

## Sumber data
`https://seratus.retroverze.my.id/status.xml` (GET, XML). Hanya game "Monster Hunter Portable 3rd".
Alamat IP pemain di XML tidak dibaca/ditampilkan. Refresh otomatis tiap 20 detik hanya saat tab Lobby Status terbuka; tombol Refresh Lobby manual; timeout 15 detik; HTTPS divalidasi normal.

## Status pengujian
- Parser XML: diuji dengan contoh status.xml asli (lolos).
- Build APK, instal, dan uji di perangkat: BELUM dilakukan (butuh GitHub Actions). Lihat bagian bawah chat untuk hasil.
